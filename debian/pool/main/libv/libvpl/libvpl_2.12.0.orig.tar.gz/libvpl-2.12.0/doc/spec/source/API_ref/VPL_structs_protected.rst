.. SPDX-FileCopyrightText: 2019-2020 Intel Corporation
..
.. SPDX-License-Identifier: CC-BY-4.0
..
  Intel(r) Video Processing Library (Intel(r) VPL)

.. _struct_protected:

====================
Protected Structures
====================

.. _struct_protected_begin:

Protected structures.

.. _struct_protected_end:

---
API
---

.. contents::
   :local:
   :depth: 1

mfxExtCencParam
----------------

.. doxygenstruct:: _mfxExtCencParam
   :project: DEF_BREATHE_PROJECT
   :members:
   :protected-members:
