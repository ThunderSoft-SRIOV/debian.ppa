.. SPDX-FileCopyrightText: 2019-2020 Intel Corporation
..
.. SPDX-License-Identifier: CC-BY-4.0

.. _VPL_api_ref:

==============================
|vpl_short_name| API Reference
==============================

.. toctree::
   :titlesonly:
   :maxdepth: 1

   VPL_functions
   VPL_structs
   VPL_enums
   VPL_defines
   VPL_ref_types
   VPL_disp_api
   VPL_guids
