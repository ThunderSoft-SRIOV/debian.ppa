.. SPDX-FileCopyrightText: 2019-2020 Intel Corporation
..
.. SPDX-License-Identifier: CC-BY-4.0

===============================
|vpl_short_name| API Versioning
===============================

|vpl_short_name| is the successor to |msdk_full_name|. |vpl_short_name| API versioning starts from
2.0. There is a correspondent version of |msdk_full_name| API which is used as a
basis for |vpl_short_name| and defined as the ``MFX_LEGACY_VERSION`` macro.

