.. SPDX-FileCopyrightText: 2019-2020 Intel Corporation
..
.. SPDX-License-Identifier: CC-BY-4.0

==========
Appendices
==========

.. toctree::
   :titlesonly:
   :maxdepth: 1

   VPL_apnds_a
   VPL_apnds_b
   VPL_apnds_c
   VPL_apnds_d
   VPL_apnds_e
   VPL_apnds_f
