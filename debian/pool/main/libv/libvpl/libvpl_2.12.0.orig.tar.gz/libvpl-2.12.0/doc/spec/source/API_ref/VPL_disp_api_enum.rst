.. SPDX-FileCopyrightText: 2019-2020 Intel Corporation
..
.. SPDX-License-Identifier: CC-BY-4.0
..
  Intel(r) Video Processing Library (Intel(r) VPL)

.. _disp_api_enum:

====================================
Dispatcher API Enumeration Reference
====================================

---
API
---

.. contents::
   :local:
   :depth: 1

mfxAccelerationMode
-------------------

.. doxygenenum:: mfxAccelerationMode
   :project: DEF_BREATHE_PROJECT

mfxImplType
-----------

.. doxygenenum:: mfxImplType
   :project: DEF_BREATHE_PROJECT
