.. SPDX-FileCopyrightText: 2021 Intel Corporation
..
.. SPDX-License-Identifier: CC-BY-4.0
..
  Intel(r) Video Processing Library (Intel(r) VPL)

================
GUIDs Reference
================

---
API
---

.. contents::
   :local:
   :depth: 1

.. doxygenvariable:: MFX_GUID_SURFACE_POOL
   :project: DEF_BREATHE_PROJECT
