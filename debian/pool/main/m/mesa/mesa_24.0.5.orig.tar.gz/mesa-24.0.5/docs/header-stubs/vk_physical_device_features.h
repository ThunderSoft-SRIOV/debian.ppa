struct vk_device_dispatch_table {};
struct vk_device_extension_table {};
struct vk_features {};
struct vk_physical_device_dispatch_table {};
