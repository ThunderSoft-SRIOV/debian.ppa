typedef enum { nir_num_opcodes = 0 } nir_op;
