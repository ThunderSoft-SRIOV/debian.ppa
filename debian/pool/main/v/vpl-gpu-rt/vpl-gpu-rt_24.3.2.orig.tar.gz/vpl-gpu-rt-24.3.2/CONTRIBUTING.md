We welcome community contributions to Intel® oneVPL GPU Runtime. Thank you for your time!

Please note that review and merge might take some time at this point.

Intel oneVPL GPU Runtime is licensed under MIT license. By contributing to the project, you agree to the license and copyright terms therein and release your contribution under these terms.