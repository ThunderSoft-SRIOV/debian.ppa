# Intel® oneVPL GPU Runtime open source
**Whats new**
 - First open source release
 - API 2.3
 - Platforms: TGL, DG1, SG1, RKL, ADL-S, ADL-P
